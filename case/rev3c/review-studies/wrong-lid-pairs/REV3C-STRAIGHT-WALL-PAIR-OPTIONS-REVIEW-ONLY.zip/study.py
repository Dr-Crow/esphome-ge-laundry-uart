"""Independent review only; never edits the case repository or qualifies prints."""
from pathlib import Path
import json, re, hashlib, sys, importlib.metadata, math
ROOT=Path(__file__).parent
REPO=Path('/workspace/scratch/c9ec93994789/ge-rev3-refinement-repo')
sys.path.insert(0,str(ROOT/'source_copy'))
from build123d import Pos, export_step, export_stl
import enclosure as e
import trimesh

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(p):
    tokens=re.findall(r'\(|\)|"(?:\\.|[^"\\])*"|[^\s()]+',p.read_text())
    stack=[]; result=None
    for t in tokens:
        if t=='(':
            x=[]
            if stack:stack[-1].append(x)
            stack.append(x)
        elif t==')': result=stack.pop()
        else:stack[-1].append(json.loads(t,strict=False) if t.startswith('"') else t)
    assert not stack
    return result
def children(x,n): return [v for v in x if isinstance(v,list) and v and v[0]==n]
def get(x,n):
    a=children(x,n); return a[0][1:] if a else None
def vol(a): return float(a.volume) if a is not None else 0.
def intersection(a,b): return vol(a&b)
def bounds(s):return [list(s.bounding_box().min),list(s.bounding_box().max)]

receipt={'classification':'REVIEW ONLY; not adopted, not physical/print qualification',
    'source_repository':str(REPO), 'preserved_commit':'77f4c8893db6c018640e25c55a3af624a3eb06b3',
    'tool_versions':{n:importlib.metadata.version(n) for n in ['build123d','trimesh','cadquery-ocp-novtk']},
    'copied_source_sha256':{p.name:sha(p) for p in (ROOT/'source_copy').iterdir()},
    'source_unchanged':{}, 'authenticated_module_geometry':{}, 'parts':{}, 'closure_checks':{}}
prov=json.loads((REPO/'pcb/rev3c/validation/xiao-model-provenance.json').read_text())
srcroot=Path('/workspace/scratch/c9ec93994789/ge-all-revision-closeout-2026-10-05/module-sourcing/primary-sources')
sources={
'c3':srcroot/'c3-v1.3-260116/202003511_XIAO ESP32C3_v1.3_SCH&PCB_260116/XIAO ESP32C3_v1.3.kicad_pcb',
'c6':srcroot/'c6-v1.0-260114/202003916_XIAO ESP32 C6_v1.0_SCH&PCB_260114/XIAO ESP32 C6.kicad_pcb'}
edges={}
for m,p in sources.items():
    d=prov['modules'][m]; assert sha(p)==d['original_pcb_sha256']
    pcb=parse(p); tx,ty=d['source_to_carrier_translation_mm']; outline=[]
    nodes=[]
    for node in pcb:
        if not isinstance(node,list):continue
        if node[0] in ['gr_line','gr_arc','gr_circle','gr_rect','gr_poly']:
            nodes.append((node,0.,0.,0.))
        if node[0]=='footprint':
            at=get(node,'at'); fx,fy=float(at[0]),float(at[1]);angle=math.radians(float(at[2]) if len(at)>2 else 0.)
            for primitive in node:
                if isinstance(primitive,list) and primitive[0] in ['fp_line','fp_arc','fp_circle','fp_rect','fp_poly']:
                    nodes.append((primitive,fx,fy,angle))
    for node,fx,fy,angle in nodes:
        if get(node,'layer')!=['Edge.Cuts']:continue
        g={'type':node[0][3:]}
        for name in ['start','mid','end','center']:
            xy=get(node,name)
            if xy:
                x,y=float(xy[0]),float(xy[1])
                g[name]=[round(x*math.cos(angle)+y*math.sin(angle)+fx+tx,4),round(-x*math.sin(angle)+y*math.cos(angle)+fy+ty,4)]
        if get(node,'pts'):g['pts']=get(node,'pts')
        outline.append(g)
    outline=sorted(outline,key=lambda x:json.dumps(x,sort_keys=True))
    edges[m]=outline
    receipt['authenticated_module_geometry'][m]={
      'source':str(p),'source_sha256':sha(p),'matches_retained_authentication_hash':True,
      'vendor_archive_url':d['vendor_archive_url'],'revision':d['revision'],
      'registered_edge_primitives':outline,'thickness_mm':float(get(get(pcb,'general'),'thickness')[0]),
      'registered_header_centers_mm':[x['carrier_kicad_xy_mm'] for x in d['fourteen_pin_centers']],
      'outline_stroke_bounds_mm':d['source_board_edge_stroke_bbox_carrier_mm']}
receipt['authenticated_module_geometry']['edge_primitive_sets_identical_0p0001mm']=edges['c3']==edges['c6']
outer={m:[g for g in edges[m] if any(p[0]<80 or p[0]>90 for n,p in g.items() if n in ['start','mid','end','center'])] for m in ['c3','c6']}
receipt['authenticated_module_geometry']['outer_edge_primitive_sets_identical_0p0001mm']=outer['c3']==outer['c6']
receipt['authenticated_module_geometry']['slot_detail_note']='Two nominal 1.27 x 0.508 mm PCB slots are shared. C6 source slot locations have a tiny (0.0095,-0.0034) mm registration difference; no milling/seating/print tolerance permits using that as a safe key.'
receipt['authenticated_module_geometry']['header_centers_identical']=receipt['authenticated_module_geometry']['c3']['registered_header_centers_mm']==receipt['authenticated_module_geometry']['c6']['registered_header_centers_mm']
receipt['module_detection']={'result':'NOT GUARANTEED',
 'basis':'The outer board contour and header pattern coincide; the two PCB slots differ only by about 0.0101 mm translation, with no manufacturing or mating bounds. No qualified distinct load-bearing module key is established. Component positions differ but are unsafe discriminators; fitted bodies, solder, cable and production lot remain incomplete.',
 'pair_key_limitation':'Base code identifies a selected plastic pair, not the module installed on the identical carrier interface.'}

# All added keys and fins are plastic outside the carrier X0..99/Y0..40 prism.
# Four points span the two button zones; dimensions are requirements for a trial.
POINTS={'c3':[(10.,-2.3),(90.,-2.3),(10.,42.3),(90.,42.3)],
        'c6':[(14.,-2.3),(94.,-2.3),(14.,42.3),(94.,42.3)]}
TOWER_BOTTOM,TOWER_TOP=2.30,14.80
FIN_BOTTOM,FIN_TOP=8.40,28.60
KEY_LIFT=TOWER_TOP-FIN_BOTTOM
TOWER_W=2.0
FIT_XY,FIT_TOP=.30,.30
B=e.B
original_base=e.base()
common_outer=e.loft([e.rr(114,54,6,e.SEAM+.2),e.rr(107,47,6,28.7),e.rr(107,47,6,e.ROOF)],ruled=True)
carrier_prism=B(0,99,0,40,-10,40)
parts={}; keys={}; fins={}
for m in ['c3','c6']:
    towers=[B(x-1,x+1,y-1,y+1,TOWER_BOTTOM,TOWER_TOP) for x,y in POINTS[m]]
    key=towers[0]
    for s in towers[1:]:key+=s
    keys[m]=key
    base=original_base+key
    assert intersection(key,carrier_prism)<1e-8
    # Each lid has broad blocking fins at both possible codes; only its own code
    # has an open-bottom channel. There is no field-adjustable selector.
    ff=[B(x0,x1,y-.0,y+2.60,FIN_BOTTOM,FIN_TOP)
        for x0,x1 in [(8.50,15.50),(88.50,95.50)] for y in [-3.60,41.00]]
    fin=ff[0]
    for s in ff[1:]:fin+=s
    fin=fin&common_outer
    for x,y in POINTS[m]:
        fin-=B(x-1-FIT_XY,x+1+FIT_XY,y-1-FIT_XY,y+1+FIT_XY,
               7.70,TOWER_TOP+FIT_TOP)
    fins[m]=fin
    parts[f'review_pair_only_base_{m}']=base
    for ant in ['internal','external']:
        original=e.shell(m,ant)
        candidate=original+fin
        for x,y in POINTS[m]:
            candidate-=B(x-1-FIT_XY,x+1+FIT_XY,y-1-FIT_XY,y+1+FIT_XY,
                         7.70,TOWER_TOP+FIT_TOP)
        candidate=candidate.clean()
        parts[f'review_pair_only_lid_{m}_{ant}']=candidate
        receipt['closure_checks'][f'{m}_{ant}_same_pair']={
          'closed_base_lid_intersection_mm3':intersection(base,candidate),
          'minimum_nominal_channel_xy_clearance_mm':FIT_XY,
          'minimum_nominal_channel_top_clearance_mm':FIT_TOP,
          'exterior_bounds_identical':bounds(original)==bounds(candidate),
          'fin_carrier_prism_intersection_mm3':intersection(fin,carrier_prism)}

for name,s in parts.items():
    assert s.is_valid,(name,'invalid')
    assert len(s.solids())==1,(name,'not single solid',len(s.solids()))
    p=ROOT/'options'/name
    export_step(s,p.with_suffix('.step'))
    export_stl(s,p.with_suffix('.stl'),tolerance=.025,angular_tolerance=.15)
    mesh=trimesh.load_mesh(p.with_suffix('.stl'))
    mesh_path=p.with_suffix('.stl')
    if not mesh.is_watertight:
        diagnostic=ROOT/'diagnostic_meshes_not_for_printing'
        diagnostic.mkdir(exist_ok=True)
        mesh_path=diagnostic/mesh_path.name
        p.with_suffix('.stl').replace(mesh_path)
    receipt['parts'][name]={'valid_solid':s.is_valid,'solid_count':len(s.solids()),
       'volume_mm3':s.volume,'bounds_mm':bounds(s),'stl_watertight':mesh.is_watertight,
       'stl_positive_volume':float(mesh.volume)>0,'step_sha256':sha(p.with_suffix('.step')),
       'stl_sha256':sha(mesh_path),'stl_path':str(mesh_path.relative_to(ROOT)),
       'stl_delivery_status':'review mesh only' if mesh.is_watertight else 'excluded from candidate package; non-manifold fin/corner tessellation'}
    print('exported',name,flush=True)

for bm,lm in [('c3','c6'),('c6','c3')]:
    base=parts[f'review_pair_only_base_{bm}']; lid=parts[f'review_pair_only_lid_{lm}_internal']
    rec={'axial_approach_only':True,'first_contact_offset_above_closed_mm':KEY_LIFT,
         'contacts':'Four integral plastic tower tips against wrong-code lid fins; no electronics discriminator',
         'sampled_offsets':[]}
    for lift in [7.00,KEY_LIFT+.01,KEY_LIFT,KEY_LIFT-.01,KEY_LIFT-.1,6.00,3.00,0.00]:
        rec['sampled_offsets'].append({'lift_mm':lift,'base_lid_intersection_mm3':intersection(base,Pos(0,0,lift)*lid)})
    rec['wrong_code_fin_key_overlap_at_0p01mm_insertion_mm3']=intersection(keys[bm],Pos(0,0,KEY_LIFT-.01)*fins[lm])
    rec['latch_feature_vertical_separation_at_key_contact_mm']=7.9+KEY_LIFT-9.4
    rec['first_contact_compliance']='UNKNOWN: no print/material/force/tilt/lateral insertion qualification'
    receipt['closure_checks'][f'{bm}_base_with_{lm}_lid']=rec

# Source C3 foot versus C6 bare-U.FL body, and key stop clearance screens.
receipt['hazard_reproduction']=[]
for stack in [11.,11.325,11.65]:
    e.configure(stack_mm=stack,reach_mode='per_assembly')
    p=e.component_proxies('c6')['ufl_max']
    for name in ['BOOT','RESET']:
        x,y=e.SW['c3'][name]; z=e.foot_z('c3',name)
        moving_foot=e.C(.52,z,22.55,x,y)
        press=e.BUTTON_TRAVEL['c3'][name]
        receipt['hazard_reproduction'].append({'stack_mm':stack,'button':name,
          'bare_ufl_rest_intersection_mm3':intersection(moving_foot,p),
          'bare_ufl_at_button_stop_intersection_mm3':intersection(Pos(0,0,-press)*moving_foot,p),
          'bare_ufl_at_wrong_pair_key_stop_intersection_mm3':intersection(Pos(0,0,KEY_LIFT-press)*moving_foot,p),
          'foot_bottom_at_wrong_pair_key_stop_mm':z-press+KEY_LIFT})
receipt['dimensions']={'units':'mm','coordinates':'Existing case datum; +Y native carrier KiCad Y; Z closed assembly',
 'coded_tower_centers':POINTS,'tower_width_xy_mm':TOWER_W,'tower_z_mm':[TOWER_BOTTOM,TOWER_TOP],
 'blocking_fin_z_mm':[FIN_BOTTOM,FIN_TOP],'channel_clearance_xy_mm':FIT_XY,
 'channel_top_clearance_mm':FIT_TOP,'nominal_wrong_pair_closed_height_prevention_mm':KEY_LIFT,
 'exterior_or_carrier_interface_changes':False,'assembly_piece_count':5,
 'piece_count_components':'One integral keyed base, one integral keyed module-specific two-button lid, three guides',
 'all_four_lid_button_functions_retained':True}
receipt['bounded_cad_repair']={'method':'Relocate four code towers and fins to straight wall spans; keep the C3/C6 4 mm code difference, 6.4 mm axial rejection lift and integral five-piece assembly',
 'old_x_mm':{'c3':[4,96],'c6':[8,100]},'new_x_mm':{'c3':[10,90],'c6':[14,94]},
 'fin_x_spans_mm':[[8.5,15.5],[88.5,95.5]],'front_back_y_unchanged':True,
 'mesh_hole_filling_or_mesh_geometry_repair_used':False,
 'original_defect':'Eight non-manifold STL edges, four incident triangles per edge, at the C3 right fin/rounded-corner transition around X98.68, Y-3.6 or 43.6, Z15.48. Original six STEP solids remained valid.'}
receipt['unknowns']=['Target module production revision/SKU/lot','Male header SKU/height/engagement and retention',
 'Installed stack and solder heights','Actual switch make, maximum travel and allowed force',
 'U.FL mated plug, cable termination, bend radius and opening slack','Ceramic antenna maximum Z',
 'Print dimensional bounds, warped closure, wall/fins strength, tilt/lateral assembly misuse',
 'Fatigue, optical, RF and thermal physical qualification']
for name,h in receipt['copied_source_sha256'].items():
    receipt['source_unchanged'][name]=sha(REPO/'case/rev3c/analytical'/name)==h
assert all(receipt['source_unchanged'].values())
(ROOT/'check-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('COMPLETE: independent review-only pair-key candidates and receipt',flush=True)
