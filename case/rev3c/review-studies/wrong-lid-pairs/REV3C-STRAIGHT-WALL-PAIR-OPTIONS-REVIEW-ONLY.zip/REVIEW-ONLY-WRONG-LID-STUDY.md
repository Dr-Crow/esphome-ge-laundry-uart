# Rev3C wrong-lid prevention study — review only

The current common base cannot be credited with recognizing the installed C3 or C6. Keep its safety status explicitly unresolved. A separate integral base/lid code can reject a mismatched plastic pair without touching electronics, while retaining five printed pieces and both closed-lid buttons. It still needs the assembler to confirm the actual module; it is not automatic module identification.

No candidate has been adopted. The case source at commit `77f4c8893db6c018640e25c55a3af624a3eb06b3` is preserved. This directory contains an independent source copy, reproducible study, separately named STEP/STL options and geometric receipts. It does not establish physical fit, print strength, materials, switch safety, optical performance or RF performance.

## Authenticated geometry

The retained original manufacturer PCB files match the authenticated SHA-256 hashes in the repository's module provenance. The study parses both original files, including the C6 board perimeter stored inside its footprint, and applies their retained translations into the carrier datum.

Manufacturer attribution: Seeed Studio, XIAO ESP32-C3 v1.3 and XIAO ESP32-C6 v1.0 hardware sources, [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Registered perimeter/slot records are derived from those sources; translations, extraction and analysis are the modifications. The enclosure source copy retains its separate original MIT license in `source_copy/LICENSE`.

- [C3 v1.3 official hardware archive](https://files.seeedstudio.com/wiki/XIAO_WiFi/Resources/XIAO_ESP32C3_v1.3_KiCad_260116.zip): original PCB SHA-256 `a761393935ff261a58fee3e3d7ecfb65152eaba8620de64ff7758fb0c043d1db`.
- [C6 v1.0 official hardware archive](https://files.seeedstudio.com/wiki/SeeedStudio-XIAO-ESP32C6/XIAO_ESP32_C6_v1.0_SCH%26PCB_260114.zip): original PCB SHA-256 `44da2bb3ffb76ae0443ef384af0c338d7ac616c4bdfb2c58258ee7ad47c95027`.
- The eight outer contour primitives coincide to the recorded 0.0001 mm precision. Their stroke bounds are X77.4633–98.4437/Y4.0148–21.8202. Both nominal board thicknesses are 1.6 mm. All fourteen registered header centers coincide.
- Both have two nominal 1.27 × 0.508 mm PCB slots. The C6 slot geometry is translated by only (0.0095, −0.0034) mm relative to C3, about 0.0101 mm. No authenticated milling, module seating or print bounds support treating this tiny shift as a safe discriminator.
- BOOT/RESET/U.FL/ceramic-antenna positions differ. These are populated electronics, with incomplete production bodies and load limits. No key is allowed to use them as a structural stop. The partial reference STEP models omit parts; omissions are not empty space that can safely receive a key.

Thus the available source does not prove a robust, safely load-bearing discriminator for a universal passive module-sensing base. This is a finding about the available authenticated geometry and unknown production lots, not a claim that every possible future mechanism is impossible.

## Alternatives requiring a user choice

| Option | Printed pieces | What it actually establishes | Tradeoff |
| --- | ---: | --- | --- |
| Common base with module-specific two-button lids and explicit module/lid check | 5 | Assembly procedure only; no physical mismatch prevention | Preserves the present common base and module swapping. Confirm module marking, USB orientation, both switch coordinates, cable routing and lid label before closure; any resistance means stop. |
| C3/C6 integral keyed base/lid pairs, common exterior and carrier interfaces | 5 per assembled case | Rejects the wrong lid for the selected base in the demonstrated aligned axial approach | Two base versions. Changing module family also needs its matching base and lid. A wrong module can still occupy a wrongly selected base, so the module check remains necessary. |
| Common base plus extra keyed insert | At least 6 | A manually selected insert codes only the chosen setting; it does not identify the module | Adds an item, installation step and incorrect-setting mode. No authenticated safe module-bound feature was found. Do not adopt a manually labeled selector as damage prevention. |

Recommendation: retain the common-base source as the analytical baseline and disclose that wrong-lid prevention remains open. Present the integral paired-base option for a decision if mechanical lid/base rejection is desired. Prefer it over a sixth-piece manual insert; do not describe either as automatic installed-module detection.

## Separate integral pair-key candidate

The files named `review_pair_only_*` demonstrate the second option. Both BOOT and RESET flexures remain integral in all four module/antenna lids. Three existing guide pieces complete the five-piece assembly. The common outer shape, mounting holes, carrier seats, connector openings, PCB/header interface, optical paths and source switch XY are retained. The only new features are integral plastic towers and internal lid fins outside the carrier X0–99/Y0–40 prism.

These keying-only CAD options retain the source's original fixed button reaches. The known original-reach failure to actuate nominal switches at the 11.0 mm installed stack remains; a separate per-assembly reach study must resolve it. Keeping both printed buttons does not establish their electrical make or safe overtravel. The independent wrong-lid contact sweep below uses the conditional calibrated reach expressly to reproduce that hazard.

All dimensions are millimetres in the existing closed-case datum:

| Feature | C3 pair | C6 pair |
| --- | --- | --- |
| Four tower center XY | (10, −2.3), (90, −2.3), (10, 42.3), (90, 42.3) | (14, −2.3), (94, −2.3), (14, 42.3), (94, 42.3) |
| Tower cross-section | 2.0 × 2.0 | 2.0 × 2.0 |
| Tower Z extent | 2.30–14.80 | 2.30–14.80 |
| Internal fin Z extent | 8.40–28.60 | 8.40–28.60 |
| Own-code open-bottom channel | 2.60 × 2.60 XY; upper end Z15.10 | Same |
| Nominal own-code channel allowance | 0.30 per XY side and above tower | Same |
| Wrong-pair first axial contact | Lid +6.40 above nominal closure | Same |

Broad fins cover both possible code positions. Only each lid's matching tower coordinates have clearance channels. The tower tips meet solid fin material on the other lid. The fin lower end clears the existing tongue. Added features are clipped to the common exterior volume and are internal; correct-code channels do not use the module as a stop.

This bounded CAD revision moves the left code group 6 mm inward and the right group 6 mm inward. Fin X spans are now 8.50–15.50 and 88.50–95.50. Both lie inside the flat spans of the front/back walls, including at the roof cavity's narrowest straight-wall span. The fins join the wall through finite plastic volume and avoid the original right fin's rounded-corner transition. The front/back key Y positions, 4 mm difference between family codes, channel allowances and early axial rejection height are retained. No mesh hole filling or geometry patching is used.

The 0.30 mm allowances are trial design requirements, not guaranteed printer capability. This code demonstrates aligned axial approach only. Lateral displacement, tilt, pushing hard enough to break a tower, warped prints and abuse need separate physical evaluation. There is no basis to guarantee prevention for arbitrary insertion or an unverified mated antenna connector.

## Bounded evidence and interpretation

`check-receipt.json` binds input hashes, tool versions, nominal closures, STEP/STL identities, source contour comparison and wrong-pair approach samples. `study.py` is reproducible with the existing pinned environment; it neither installs packages nor edits the repository.

All six candidates are valid single-solid BReps with positive volume. All four correct module/antenna pair closures have zero base/lid volume intersection. Both wrong directions are clear at lid lift 6.41 mm, first touch at 6.40 mm, and overlap 0.160 mm³ at 6.39 mm. At that first contact the latch features remain 4.90 mm vertically separated. The candidate fins have zero intersection with the full carrier prism, and original lid exterior bounds are preserved.

The prior corner placement produced eight non-manifold edges in each C3 STL export, with four incident triangles per edge, around X98.68, Y−3.6 or 43.6, Z15.48. The previous six STEP solids were valid; STEP reimport did not resolve the mesh artifact. That placement and its diagnostics remain in the original study directory. This revised directory contains the separate straight-wall CAD attempt. Final per-file STEP/STL checks and closure/contact results are recorded in `check-receipt.json`.

The straight-wall revision exports all six STL meshes watertight with positive signed volume. Both C3 lid meshes now pass without mesh filling, vertex merging, triangle deletion or other mesh repair. `verify_exports.py` reimports the six final STEP files, checks the six corresponding unmodified STL files and repeats correct/wrong approach checks against the exported STEP geometry. This establishes CAD/mesh consistency for a reviewable trial; it does not establish print or material qualification.

The known wrong-lid mechanism is reproduced independently. C3 BOOT lies 0.189756 mm from the C6 U.FL center. Across installed stack samples 11.0, 11.325 and 11.65 mm, the calibrated C3 BOOT tip at its nominal 0.40 mm button stop intersects the 3.1 × 3.0 × 1.45 mm bare-U.FL screen by 0.084949 mm³. At the nominal release position it does not intersect that bare body. A mated plug/cable is unknown. C3 RESET projects into the ceramic antenna's XY region, but its maximum Z remains unknown.

The pair-code stop keeps the C3 BOOT tip above the bare-U.FL screen even at the full nominal press. This geometric screen supports the demonstrated aligned wrong-pair rejection. It does not validate a damaged or incorrectly selected base, or a C6 module mistakenly installed in a C3-coded base.

Before physical or release use, resolve target module revision/lot, fitted switch identity and make/force/overtravel limits, actual male headers and seating/retention, installed stack/solder height, U.FL plug and cable bodies/bend/slack, ceramic maximum Z, print dimensional/warp/strength bounds and complete unpowered assembly. Existing guide/cap, optical, RF, thermal and fatigue gates remain.

See `key-layout-and-first-contact.svg` for the dimensioned plan and the nominal first-contact explanation. Review STEP solids are the geometric authority; the receipt separately reports mesh validity.
