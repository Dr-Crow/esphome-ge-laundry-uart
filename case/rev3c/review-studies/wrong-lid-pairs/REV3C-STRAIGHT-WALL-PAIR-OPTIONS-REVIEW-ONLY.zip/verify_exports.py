"""Read final exported STEP/STL geometry; never repair a mesh or edit source."""
from pathlib import Path
import json, hashlib
from build123d import import_step,Pos
import trimesh,numpy as np
ROOT=Path(__file__).parent
def overlap_volume(a,b):
    result=a&b
    return 0. if result is None else float(result.volume)
p=json.loads((ROOT/'check-receipt.json').read_text())
parts={}; checks={'six_artifact_pairs':{},'correct_approach':{},'wrong_approach':{}}
for name,r in p['parts'].items():
    step=ROOT/'options'/f'{name}.step';mesh_path=ROOT/r['stl_path']
    assert hashlib.sha256(step.read_bytes()).hexdigest()==r['step_sha256']
    assert hashlib.sha256(mesh_path.read_bytes()).hexdigest()==r['stl_sha256']
    s=import_step(step);parts[name]=s
    m=trimesh.load_mesh(mesh_path)
    counts=np.bincount(m.edges_unique_inverse)
    rec={'step_reimport_valid':bool(s.is_valid),'step_reimport_solid_count':len(s.solids()),
      'step_reimport_volume_mm3':float(s.volume),'step_reimport_volume_delta_mm3':float(s.volume-r['volume_mm3']),
      'stl_watertight':bool(m.is_watertight),'stl_winding_consistent':bool(m.is_winding_consistent),
      'stl_positive_signed_volume':bool(m.volume>0),'stl_non_two_incident_edge_count':int(np.sum(counts!=2)),
      'stl_signed_volume_mm3':float(m.volume),'stl_volume_difference_percent':100*(m.volume-s.volume)/s.volume,
      'stl_vertex_count':len(m.vertices),'stl_face_count':len(m.faces),
      'mesh_repair_used':False}
    assert rec['step_reimport_valid'] and rec['step_reimport_solid_count']==1 and s.volume>0
    assert rec['stl_watertight'] and rec['stl_winding_consistent'] and rec['stl_positive_signed_volume']
    assert rec['stl_non_two_incident_edge_count']==0
    checks['six_artifact_pairs'][name]=rec
    print('verified artifact pair',name,flush=True)
for module in ['c3','c6']:
    base=parts[f'review_pair_only_base_{module}']
    for ant in ['internal','external']:
        lid=parts[f'review_pair_only_lid_{module}_{ant}'];rows=[]
        for lift in [6.39,3.,0.]:
            overlap=overlap_volume(base,Pos(0,0,lift)*lid)
            assert overlap<1e-8,(module,ant,lift,overlap)
            rows.append({'lift_mm':lift,'intersection_mm3':overlap})
        checks['correct_approach'][f'{module}_{ant}']=rows
for bm,lm in [('c3','c6'),('c6','c3')]:
    base=parts[f'review_pair_only_base_{bm}']
    for ant in ['internal','external']:
        lid=parts[f'review_pair_only_lid_{lm}_{ant}'];rows=[]
        for lift in [6.41,6.4,6.39]:
            overlap=overlap_volume(base,Pos(0,0,lift)*lid)
            assert (overlap<1e-8 if lift>=6.4 else abs(overlap-.16)<1e-7),(bm,lm,ant,lift,overlap)
            rows.append({'lift_mm':lift,'intersection_mm3':overlap})
        checks['wrong_approach'][f'{bm}_base_{lm}_{ant}_lid']=rows
checks['result']='PASS: six STEP reimports/six unmodified STL meshes, four correct closures and both wrong directions for both antenna versions'
p['export_reimport_verification']=checks
(ROOT/'check-receipt.json').write_text(json.dumps(p,indent=2)+'\n')
print(checks['result'],flush=True)
